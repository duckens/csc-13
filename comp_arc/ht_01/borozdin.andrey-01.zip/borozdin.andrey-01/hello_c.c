#include <stdio.h>


// int foo(int x){
// 	return 2;
// }

int main(){

	puts("hello world\n");

	return 0;
}