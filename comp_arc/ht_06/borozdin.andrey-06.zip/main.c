#include <stdio.h>

int putsprint(char* ptr);

int main(){

	char str[17] = "Hello putsprint";
	putsprint(str);

	return 0;
}
