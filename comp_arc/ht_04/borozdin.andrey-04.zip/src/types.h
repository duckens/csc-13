#ifndef TYPES_H
#define TYPES_H

typedef unsigned long long int uint64_t;
typedef unsigned int uint32_t;

#endif
